if = Nge
do = bo
pour = asu

- = akok_lo
  = = aveu
  == = Dzam_deuh  
  != = asseulen
  > = abui
  > < = Aboite
  > while = ntie_te
  > else = nde_ya
  > then = ndo
