flex -o exo7.yy.c exo7.lex
gcc -o exo7 exo7.yy.c -lfl
 
