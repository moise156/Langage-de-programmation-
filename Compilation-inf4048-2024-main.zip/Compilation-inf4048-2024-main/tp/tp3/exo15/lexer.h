#ifndef LEXER_H
#define LEXER_H

#include <stdlib.h>

extern int yylval;

#endif // LEXER_H
