# Assurez-vous que le fichier a les permissions d'exécution
#Utilisez la commande :chmod +x script.sh
#Il suffit de saisir la commande:
grep -c -E '^if.*n$' /etc/bash.bashrc
